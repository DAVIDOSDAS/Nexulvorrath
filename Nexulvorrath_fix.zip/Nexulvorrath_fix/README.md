# Nexulvorrath (Minecraft 1.21.1)

> "It isn't just watching the game. It is watching the environment."

Nexulvorrath is an anomalous stalking entity built for Minecraft Forge 1.21.1. It does not behave like a standard monster. It modifies client behaviors, monitors your patterns, and interacts with your local system footprint. 

Discovering what it is capable of is up to you. 

---

## 🛑 Banishment Ritual (How to Survive)

If the entity traps you in total darkness and you can no longer move, **do not panic.** 
1. You must remain completely stationary.
2. While blinded in the dark, drop **Crying Obsidian** onto the ground at your feet. 

If executed correctly, the anomaly matrix will be forcibly purged from the active sector. Fail to react in time, and the world file integrity will be terminated.

---

The mod will make you want to delete it.
